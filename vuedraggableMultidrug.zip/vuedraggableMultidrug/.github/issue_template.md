First check https://github.com/SortableJS/Vue.Draggable/blob/master/CONTRIBUTING.md

### Jsfiddle link

### Step by step scenario

### Actual Solution

### Expected Solution
