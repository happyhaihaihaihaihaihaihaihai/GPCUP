export function computeComponentStructure({ $slots, tag, realList, getKey }: {
    $slots: any;
    tag: any;
    realList: any;
    getKey: any;
}): ComponentStructure;
import { ComponentStructure } from "./componentStructure";
