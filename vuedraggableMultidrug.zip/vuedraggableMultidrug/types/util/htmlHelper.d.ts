export function insertNodeAt(fatherNode: any, node: any, position: any): void;
export function removeNode(node: any): void;
