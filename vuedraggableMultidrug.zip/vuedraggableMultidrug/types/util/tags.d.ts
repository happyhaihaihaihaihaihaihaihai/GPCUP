export function isHtmlTag(name: any): boolean;
export function isHtmlAttribute(value: any): any;
export function isTransition(name: any): boolean;
