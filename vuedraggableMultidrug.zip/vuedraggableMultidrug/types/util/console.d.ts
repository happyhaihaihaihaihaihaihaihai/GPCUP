export const console: Console;
