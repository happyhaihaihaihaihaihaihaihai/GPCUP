module.exports = {
  presets: [["@vue/app", {
    useBuiltIns: "usage"
  }]
  ]
};
