<template>
  <slot></slot>
</template>
<script>
import draggable from "@/vuedraggable";

export default {};
</script>
